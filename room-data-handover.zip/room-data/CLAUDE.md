# Room data app

## What this is

A web app replacing the Excel-based room data sheet (RDS) process at Cox Architecture. Today, strict Excel templates go out to engineering consultants, come back broken, and have to be maintained as multiple per-discipline copies. When rooms are added they have to be added to every copy. Consultants also struggle to authenticate to Cox's Microsoft tenancy, so live SharePoint files aren't an option.

This app keeps **one** room list per project. Each consultant signs in with an emailed one-time code (no Cox account needed) and edits only their own discipline's columns in a shared live grid. Architects (admins) manage rooms, columns and people.

The owner is an architect, not a full-time developer. Prefer simple, readable solutions over clever ones, and explain trade-offs in plain language.

## Current state

Working prototype, being trialled on Supabase's free tier.

- `public/index.html`: the entire front end. Vanilla JS, single file, no build step. Loads `@supabase/supabase-js@2.45.4` UMD from jsDelivr and Archivo from Google Fonts.
- `supabase/migrations/20261019000000_init.sql`: full schema, RLS policies, triggers, realtime publication. Applied by pasting into the Supabase SQL Editor (CLI not yet set up).

Config (Supabase URL + anon key) is hardcoded near the bottom of `index.html` in the CONFIG block. The anon key is public by design; RLS is the security boundary.

## Architecture

```
Static page (index.html)  ──supabase-js──▶  Supabase
                                             ├─ Auth: email OTP / magic link
                                             ├─ Postgres + RLS (all permissions live here)
                                             └─ Realtime: postgres_changes on room_values etc.
```

There is no custom server. **All authorisation is enforced in Postgres via RLS and triggers.** The front end hides things for UX only; never rely on it for security.

## Data model

- `projects`: created only via `create_project(p_name)` RPC (security definer), which also makes the caller admin.
- `project_members (project_id, email, role, disciplines text[])`: keyed by **lowercased email**, not user id, so people can be added before they've ever signed in. Roles: `admin`, `consultant`, `viewer`.
- `rooms (project_id, code unique per project, name, level, area, sort_order)`
- `fields`: one row per sheet column: `label, discipline, type (text|number|select|checkbox), options text[], sort_order`. Adding a column is an insert, never a migration.
- `room_values (room_id, field_id) PK, value text, project_id, updated_by, updated_at`: one row per filled cell (EAV). All values stored as text; type is enforced by trigger.
- `value_history`: append-only audit log written by trigger.

## Key mechanics

- Helper functions `current_email()`, `is_member(p)`, `is_admin(p)`, `can_edit_value(room, field)`. The latter three are `security definer` to avoid RLS recursion on `project_members`.
- `room_values_before` trigger: sets `project_id` from the room, overwrites `updated_by`/`updated_at` (can't be spoofed), converts `''` to null, validates value against the field type/options.
- `room_values_after` trigger: writes `value_history`.
- Consultants can edit a cell iff `field.discipline = any(member.disciplines)`. Admins can edit everything. Viewers read only.
- Admins can't delete or demote their own membership row (prevents orphaned projects).
- Front end writes cells with `upsert(..., { onConflict: 'room_id,field_id' })`, which needs INSERT, UPDATE and SELECT policies.
- Reads paginate with `fetchAll()` because PostgREST caps responses at 1000 rows by default; a 300-room × 40-column project is 12k cells.
- Realtime: `room_values` changes patch cells in place (skipping the focused cell); changes to `rooms`/`fields`/`project_members` trigger a debounced full reload that preserves scroll and focus.
- Routing is hash-based: `#p=<project uuid>`. Supabase auth tokens also arrive in the hash after a magic link; `currentProjectId()` only matches the `#p=` form.
- Never `await` Supabase calls inside `onAuthStateChange`; the code defers with `setTimeout`.

## Known limitations / gotchas

- **Email:** Supabase's default SMTP only delivers to members of the Supabase org team and is limited to roughly 2 emails/hour. Custom SMTP (Resend, Brevo, etc.) is required before inviting real consultants.
- Email templates (Magic Link and Confirm Signup) must include `{{ .Token }}` for the code-entry path to work. Corporate mail scanners sometimes consume magic links, so the code path matters.
- Free tier projects pause after a week of inactivity.
- Anyone who signs in can create a project. Fine for a trial; should be restricted (e.g. allowlist or email domain) before wider use.
- Realtime DELETE events on `rooms`/`fields` aren't filtered by `project_id`, so other users may not see deletions until their next reload.
- Room deletes cascade to all values. There's a confirm dialog, but no soft delete or undo.
- Adding a member doesn't email them; the admin shares the link manually.
- `index.html` must be served over http(s), not opened via `file://`, for magic-link redirects.

## Design conventions

- Theme via CSS custom properties on `:root`, with a `prefers-color-scheme: dark` override. Every colour comes from a variable.
- Discipline colours come from `PALETTE`, assigned by alphabetical position of the discipline name.
- Room codes render as "room tags" (pill outline), echoing tags on architectural plans.
- UI copy: sentence case, plain verbs, buttons say exactly what they do ("Add room", not "Submit"). Typographic apostrophes (’) in user-facing text.
- Error toasts state what went wrong and how to fix it.

## Working on this repo

- Keep the front end build-free unless there's a clear reason to change. If it grows past roughly 1,500 lines, propose a split (e.g. ES modules, still no bundler) before doing it.
- Schema changes go in **new** timestamped files in `supabase/migrations/`; never edit an applied migration.
- Any new table needs RLS enabled and explicit policies in the same migration.
- Test permission changes as all three roles. A quick way: sign in as yourself (admin) and as a second address added as a consultant.
- Before committing, run a syntax check on the inline script (e.g. extract it and `node --check`).

See `docs/ROADMAP.md` for prioritised next steps.
