# Roadmap

Ordered roughly by priority. Each item is sized to be a single focused task.

## Before inviting real consultants

1. **Move config out of index.html.** Put the Supabase URL and anon key in a small `public/config.js` (committed with placeholders, real values set per deployment) so the main file doesn't need editing per environment.
2. **Restrict project creation.** Add an allowlist (table of emails or an allowed email domain such as `@cox.com.au`) checked inside `create_project()`.
3. **Set up the Supabase CLI.** Link the repo to the project so migrations are applied with `supabase db push` instead of pasting SQL.
4. **Deploy.** Static hosting (Netlify, Cloudflare Pages or GitHub Pages). Add the deployed URL to Supabase Auth → URL Configuration.
5. **Custom SMTP.** Document the chosen provider and the template changes (`{{ .Token }}` in Magic Link and Confirm Signup).

## Core usability

6. **Column reordering** in the Columns drawer (drag or up/down buttons updating `sort_order`).
7. **Edit columns**, not just add/delete: rename, change options for select columns, change discipline. Warn when removing an option that's in use.
8. **Cell history view.** Click a cell (or a small icon) to see its `value_history`: who, when, old → new.
9. **Paste a block of values** into the grid from Excel (multi-row, multi-column), respecting edit permissions and validating per cell.
10. **Excel export (.xlsx)** with one sheet per discipline plus an "All" sheet, via SheetJS. Keep CSV too.
11. **Filter by level**, and sort by any column.

## Data integrity

12. **Soft-delete rooms** (an `archived_at` column) instead of cascading deletes, with a restore option for admins.
13. **Fix realtime deletes:** handle DELETE payloads (which only carry the primary key) so other users see removed rooms and columns without a reload.
14. **Required columns / completeness.** Mark fields as required and show per-discipline completion percentages, so the architect can see who still owes data.

## Later

15. **Room templates / room types.** Define default values per room type (e.g. "Consult room") and apply them to many rooms at once.
16. **Revit round-trip.** Import rooms from a Revit schedule export and export values back in a format a Dynamo script can read.
17. **Per-project disciplines table** with a fixed colour per discipline, rather than colour by alphabetical position.
18. **Invitation emails** sent via an Edge Function when an admin adds someone.
19. **Comments on cells** for consultant ↔ architect queries, replacing email threads.
