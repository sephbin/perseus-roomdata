# Room data

A shared, live room data sheet for architects and their consultants. One room list per project, each consultant edits only their discipline's columns, and nobody needs a Cox Microsoft account.

Built on Supabase (Postgres, auth, realtime) with a single static HTML page as the front end.

## Setup

1. Create a Supabase project (Sydney region).
2. In the SQL Editor, run `supabase/migrations/20261019000000_init.sql`.
3. From Project Settings → API, copy the Project URL and anon key into the CONFIG block in `public/index.html`.
4. Serve the `public` folder over http, for example `npx serve public` or `python -m http.server -d public`.
5. In Authentication → URL Configuration, set the Site URL to wherever it's served.
6. In Authentication → Email Templates, add `{{ .Token }}` to the Magic Link and Confirm Signup templates so people can sign in with a code.
7. Before inviting anyone outside your Supabase team, configure custom SMTP under Authentication → SMTP. The built-in sender only emails team members and is heavily rate-limited.

## Using it

Sign in, create a project, then use the admin buttons:

- **Rooms:** add one at a time, or paste code/name/level/area straight from Excel or a Revit schedule. Pasting a code that already exists updates it.
- **Columns:** add columns grouped by discipline, as text, number, dropdown list or tick box.
- **People:** add consultants by email with their disciplines, then send them the link.

Every change is recorded in the `value_history` table.

## Repo layout

```
public/index.html          the whole front end
supabase/migrations/       database schema, security rules, triggers
docs/ROADMAP.md            prioritised next steps
CLAUDE.md                  context for Claude Code
```
